TP 2 A à C - AER8275
Pour exécuter le code générant les réponses numériques des questions 5, 6 et 7 :
- Exécuter la fonction TP2C_main.py à l'aide de python  3.10 ou ultérieure.
- Les résultats seront indiqués dans la sortie de ligne de commande.
- Les graphiques seront générés et affichés si exécuté avec un IDE (ex: Spyder)
- Pour tester d'autres configurations de performance avion ou de
  conditions atmosphériques, utiliser les fonctions des fichier TP1A.py,
  TP1B.py, TP2A et TP2B. 
- Les fonctions des TP2A et B peuvent être testés en exécutant ou modifiant
  les fichiers TP2A_main.py et TP2B_main.py.