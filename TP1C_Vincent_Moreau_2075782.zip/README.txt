TP 1 A à C - AER8275
Pour exécuter le code générant les réponses numériques des questions 4 à 5 :
- Exécuter la fonction TP1C_Vincent.py à l'aide de python  3.10 ou ultérieure.
- Les résultats seront indiqués dans la sortie de ligne de commande.
- Pour tester d'autres configurations de performance avion ou de
  conditions atmosphériques, utiliser les fonctions atmosphere et 
  parametres_de_vol des fichiers TP1A.py et TP1B.py