TP 3 A à C - AER8275
Pour exécuter le code générant les réponses numériques de la question 3 :
- Exécuter la fonction TP3C.py à l'aide de python  3.10 ou ultérieure.
- Les résultats seront indiqués dans la sortie de ligne de commande.
- Les graphiques seront générés et affichés si exécuté avec un IDE (ex: Spyder)
- Pour tester d'autres configurations de performance avion ou de
  conditions atmosphériques, utiliser les fonctions des fichier TP1A.py,
  TP1B.py, TP2A et TP2B. 
- Les fonctions des TP3A et B peuvent être testés en exécutant ou modifiant
  les fichiers TP3A_main.py et TP3B_main.py.